'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { ListingCard } from '@/components/listing-card'
import { Filters } from '@/components/filters'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { SORT_OPTIONS } from '@/lib/constants'
import { Listing } from '@/lib/types'
import { Loader2 } from 'lucide-react'

export default function BrowsePage() {
  const [listings, setListings] = useState<Listing[]>([])
  const [loading, setLoading] = useState(true)
  const [favorites, setFavorites] = useState<string[]>([])
  
  const searchParams = useSearchParams()
  const router = useRouter()
  const supabase = createClient()

  const [search, setSearch] = useState(searchParams.get('search') || '')
  const [category, setCategory] = useState(searchParams.get('category') || '')
  const [condition, setCondition] = useState(searchParams.get('condition') || '')
  const [city, setCity] = useState(searchParams.get('city') || '')
  const [minPrice, setMinPrice] = useState(searchParams.get('minPrice') || '')
  const [maxPrice, setMaxPrice] = useState(searchParams.get('maxPrice') || '')
  const [sort, setSort] = useState(searchParams.get('sort') || 'newest')

  const updateURL = useCallback((params: Record<string, string>) => {
    const newParams = new URLSearchParams()
    Object.entries(params).forEach(([key, value]) => {
      if (value && value !== 'all') {
        newParams.set(key, value)
      }
    })
    router.push(`/browse?${newParams.toString()}`, { scroll: false })
  }, [router])

  const fetchListings = useCallback(async () => {
    setLoading(true)
    
    let query = supabase
      .from('listings')
      .select('*, profiles(name, avatar)')

    if (search) {
      query = query.ilike('title', `%${search}%`)
    }
    if (category && category !== 'all') {
      query = query.eq('category', category)
    }
    if (condition && condition !== 'all') {
      query = query.eq('condition', condition)
    }
    if (city && city !== 'all') {
      query = query.eq('city', city)
    }
    if (minPrice) {
      query = query.gte('price', parseInt(minPrice))
    }
    if (maxPrice) {
      query = query.lte('price', parseInt(maxPrice))
    }

    switch (sort) {
      case 'price-low':
        query = query.order('price', { ascending: true })
        break
      case 'price-high':
        query = query.order('price', { ascending: false })
        break
      default:
        query = query.order('created_at', { ascending: false })
    }

    const { data, error } = await query

    if (error) {
      console.error('Error fetching listings:', error)
    } else {
      setListings(data || [])
    }
    setLoading(false)
  }, [supabase, search, category, condition, city, minPrice, maxPrice, sort])

  const fetchFavorites = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      const { data } = await supabase
        .from('favorites')
        .select('listing_id')
        .eq('user_id', user.id)
      
      if (data) {
        setFavorites(data.map(f => f.listing_id))
      }
    }
  }, [supabase])

  useEffect(() => {
    fetchListings()
    fetchFavorites()
  }, [fetchListings, fetchFavorites])

  useEffect(() => {
    const timer = setTimeout(() => {
      updateURL({ search, category, condition, city, minPrice, maxPrice, sort })
    }, 300)
    return () => clearTimeout(timer)
  }, [search, category, condition, city, minPrice, maxPrice, sort, updateURL])

  const clearFilters = () => {
    setSearch('')
    setCategory('')
    setCondition('')
    setCity('')
    setMinPrice('')
    setMaxPrice('')
    setSort('newest')
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-foreground">Browse Listings</h1>
        
        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters Sidebar */}
          <aside className="w-full md:w-64 shrink-0">
            <Filters
              search={search}
              category={category}
              condition={condition}
              city={city}
              minPrice={minPrice}
              maxPrice={maxPrice}
              onSearchChange={setSearch}
              onCategoryChange={setCategory}
              onConditionChange={setCondition}
              onCityChange={setCity}
              onMinPriceChange={setMinPrice}
              onMaxPriceChange={setMaxPrice}
              onClearFilters={clearFilters}
            />
          </aside>

          {/* Listings Grid */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-6">
              <p className="text-muted-foreground">
                {loading ? 'Loading...' : `${listings.length} listings found`}
              </p>
              <Select value={sort} onValueChange={setSort}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  {SORT_OPTIONS.map((option) => (
                    <SelectItem key={option.id} value={option.id}>
                      {option.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {loading ? (
              <div className="flex items-center justify-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : listings.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {listings.map((listing) => (
                  <ListingCard
                    key={listing.id}
                    listing={listing}
                    isFavorite={favorites.includes(listing.id)}
                    onFavoriteToggle={fetchFavorites}
                  />
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground mb-4">No listings found matching your criteria.</p>
                <Button onClick={clearFilters}>Clear Filters</Button>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
