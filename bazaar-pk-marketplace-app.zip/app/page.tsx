import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ListingCard } from '@/components/listing-card'
import { CATEGORIES } from '@/lib/constants'
import { Listing } from '@/lib/types'
import { 
  ShoppingBag, 
  ArrowRight, 
  Smartphone, 
  Laptop, 
  Sofa, 
  Shirt, 
  Tv, 
  BookOpen, 
  Car, 
  Refrigerator 
} from 'lucide-react'

const categoryIcons: Record<string, React.ReactNode> = {
  mobile: <Smartphone className="h-8 w-8" />,
  laptop: <Laptop className="h-8 w-8" />,
  furniture: <Sofa className="h-8 w-8" />,
  kapray: <Shirt className="h-8 w-8" />,
  electronics: <Tv className="h-8 w-8" />,
  books: <BookOpen className="h-8 w-8" />,
  cars: <Car className="h-8 w-8" />,
  'home-appliances': <Refrigerator className="h-8 w-8" />,
}

export default async function Home() {
  const supabase = await createClient()
  
  const { data: listings } = await supabase
    .from('listings')
    .select('*, profiles(name, avatar)')
    .order('created_at', { ascending: false })
    .limit(8)

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-4 bg-gradient-to-b from-primary/20 to-background">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center gap-3 mb-6">
            <ShoppingBag className="h-12 w-12 text-primary" />
            <h1 className="text-4xl md:text-6xl font-bold text-foreground">
              Bazaar<span className="text-primary">PK</span>
            </h1>
          </div>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Pakistan&apos;s trusted marketplace for second-hand goods. Buy and sell mobiles, laptops, furniture, cars, and more!
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/browse">
              <Button size="lg" className="gap-2">
                Browse Listings
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/post">
              <Button size="lg" variant="outline">
                Post Your Ad
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 px-4 bg-card">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-10 text-foreground">
            Browse by Category
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {CATEGORIES.map((category) => (
              <Link key={category.id} href={`/browse?category=${category.id}`}>
                <Card className="group hover:border-primary/50 transition-all duration-200 cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <div className="mb-3 text-primary group-hover:scale-110 transition-transform duration-200 flex justify-center">
                      {categoryIcons[category.id]}
                    </div>
                    <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                      {category.name}
                    </h3>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Recent Listings Section */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-10">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground">
              Recent Listings
            </h2>
            <Link href="/browse">
              <Button variant="ghost" className="gap-2">
                View All
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
          {listings && listings.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {listings.map((listing: Listing) => (
                <ListingCard key={listing.id} listing={listing} />
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center">
              <p className="text-muted-foreground mb-4">No listings yet. Be the first to post!</p>
              <Link href="/post">
                <Button>Post Your Ad</Button>
              </Link>
            </Card>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border">
        <div className="max-w-7xl mx-auto text-center text-muted-foreground">
          <p>&copy; 2024 BazaarPK. All rights reserved.</p>
          <p className="mt-2 text-sm">Designed by Husnain Abbasi</p>
        </div>
      </footer>
    </div>
  )
}
