'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Listing } from '@/lib/types'
import { CATEGORIES, CONDITIONS } from '@/lib/constants'
import { 
  Heart, 
  MapPin, 
  MessageCircle, 
  Calendar, 
  ChevronLeft, 
  ChevronRight,
  ArrowLeft
} from 'lucide-react'

interface ListingDetailProps {
  listing: Listing
}

export function ListingDetail({ listing }: ListingDetailProps) {
  const [currentImage, setCurrentImage] = useState(0)
  const [isFavorite, setIsFavorite] = useState(false)
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const checkFavorite = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const { data } = await supabase
          .from('favorites')
          .select('id')
          .eq('user_id', user.id)
          .eq('listing_id', listing.id)
          .single()
        
        setIsFavorite(!!data)
      }
    }
    checkFavorite()
  }, [supabase, listing.id])

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-PK', {
      style: 'currency',
      currency: 'PKR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price).replace('PKR', 'Rs.')
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-PK', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    })
  }

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'brand-new':
        return 'bg-green-500/20 text-green-400 border-green-500/30'
      case 'good':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30'
      case 'fair':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
      case 'needs-repair':
        return 'bg-red-500/20 text-red-400 border-red-500/30'
      default:
        return 'bg-muted text-muted-foreground'
    }
  }

  const getCategoryName = (categoryId: string) => {
    return CATEGORIES.find(c => c.id === categoryId)?.name || categoryId
  }

  const getConditionName = (conditionId: string) => {
    return CONDITIONS.find(c => c.id === conditionId)?.name || conditionId
  }

  const handleFavoriteClick = async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/auth/login')
      return
    }

    setLoading(true)
    try {
      if (isFavorite) {
        await supabase
          .from('favorites')
          .delete()
          .eq('user_id', user.id)
          .eq('listing_id', listing.id)
      } else {
        await supabase
          .from('favorites')
          .insert({ user_id: user.id, listing_id: listing.id })
      }
      setIsFavorite(!isFavorite)
    } catch (error) {
      console.error('Error toggling favorite:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent(`Hi, I'm interested in your listing: ${listing.title} (${formatPrice(listing.price)})`)
    const phone = listing.whatsapp.replace(/[^0-9]/g, '')
    const formattedPhone = phone.startsWith('0') ? '92' + phone.slice(1) : phone
    window.open(`https://wa.me/${formattedPhone}?text=${message}`, '_blank')
  }

  const images = listing.images?.length > 0 ? listing.images : ['/placeholder.svg']

  const nextImage = () => {
    setCurrentImage((prev) => (prev + 1) % images.length)
  }

  const prevImage = () => {
    setCurrentImage((prev) => (prev - 1 + images.length) % images.length)
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <Button
          variant="ghost"
          className="mb-6 gap-2"
          onClick={() => router.back()}
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="relative aspect-[4/3] rounded-lg overflow-hidden bg-card">
              <Image
                src={images[currentImage]}
                alt={listing.title}
                fill
                className="object-cover"
              />
              {images.length > 1 && (
                <>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute left-2 top-1/2 -translate-y-1/2 bg-background/80 backdrop-blur-sm"
                    onClick={prevImage}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-2 top-1/2 -translate-y-1/2 bg-background/80 backdrop-blur-sm"
                    onClick={nextImage}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </>
              )}
              <div className="absolute bottom-2 right-2 bg-background/80 backdrop-blur-sm px-2 py-1 rounded text-sm">
                {currentImage + 1} / {images.length}
              </div>
            </div>

            {images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2">
                {images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImage(index)}
                    className={`relative w-20 h-20 rounded-md overflow-hidden shrink-0 border-2 transition-colors ${
                      index === currentImage ? 'border-primary' : 'border-transparent'
                    }`}
                  >
                    <Image
                      src={image}
                      alt={`${listing.title} ${index + 1}`}
                      fill
                      className="object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Listing Info */}
          <div className="space-y-6">
            <div>
              <div className="flex items-start justify-between gap-4 mb-2">
                <h1 className="text-2xl md:text-3xl font-bold text-foreground">
                  {listing.title}
                </h1>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleFavoriteClick}
                  disabled={loading}
                >
                  <Heart
                    className={`h-6 w-6 ${isFavorite ? 'fill-primary text-primary' : 'text-foreground'}`}
                  />
                </Button>
              </div>
              <p className="text-3xl font-bold text-primary">
                {formatPrice(listing.price)}
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary">{getCategoryName(listing.category)}</Badge>
              <Badge className={getConditionColor(listing.condition)}>
                {getConditionName(listing.condition)}
              </Badge>
            </div>

            <div className="flex items-center gap-4 text-muted-foreground">
              <div className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                {listing.city}
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {formatDate(listing.created_at)}
              </div>
            </div>

            <Card>
              <CardContent className="p-4">
                <h2 className="font-semibold mb-2 text-foreground">Description</h2>
                <p className="text-muted-foreground whitespace-pre-wrap">
                  {listing.description || 'No description provided.'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <h2 className="font-semibold mb-4 text-foreground">Seller Information</h2>
                <div className="flex items-center gap-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={listing.profiles?.avatar || undefined} />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {listing.profiles?.name?.charAt(0).toUpperCase() || 'S'}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-foreground">
                      {listing.profiles?.name || 'Seller'}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {listing.whatsapp}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button
              size="lg"
              className="w-full gap-2 bg-green-600 hover:bg-green-700 text-white"
              onClick={handleWhatsAppClick}
            >
              <MessageCircle className="h-5 w-5" />
              Contact via WhatsApp
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
