import { notFound } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { ListingDetail } from './listing-detail'

interface Props {
  params: Promise<{ id: string }>
}

export default async function ListingPage({ params }: Props) {
  const { id } = await params
  const supabase = await createClient()

  const { data: listing, error } = await supabase
    .from('listings')
    .select('*, profiles(name, avatar)')
    .eq('id', id)
    .single()

  if (error || !listing) {
    notFound()
  }

  return <ListingDetail listing={listing} />
}
