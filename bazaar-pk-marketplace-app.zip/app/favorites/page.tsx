'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'
import { ListingCard } from '@/components/listing-card'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Listing } from '@/lib/types'
import { Loader2, Heart } from 'lucide-react'

export default function FavoritesPage() {
  const [favorites, setFavorites] = useState<(Listing & { favoriteId: string })[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  const fetchFavorites = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/auth/login')
      return
    }

    const { data, error } = await supabase
      .from('favorites')
      .select('id, listing_id, listings(*, profiles(name, avatar))')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })

    if (error) {
      console.error('Error fetching favorites:', error)
    } else if (data) {
      const listingsWithFavoriteId = data
        .filter(f => f.listings)
        .map(f => ({
          ...(f.listings as Listing),
          favoriteId: f.id,
        }))
      setFavorites(listingsWithFavoriteId)
    }
    setLoading(false)
  }, [supabase, router])

  useEffect(() => {
    fetchFavorites()
  }, [fetchFavorites])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-2 mb-8">
          <Heart className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold text-foreground">My Favorites</h1>
        </div>

        {favorites.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {favorites.map((listing) => (
              <ListingCard
                key={listing.id}
                listing={listing}
                isFavorite={true}
                onFavoriteToggle={fetchFavorites}
              />
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <Heart className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground mb-4">You haven&apos;t saved any favorites yet.</p>
            <Link href="/browse">
              <Button>Browse Listings</Button>
            </Link>
          </Card>
        )}
      </div>
    </div>
  )
}
