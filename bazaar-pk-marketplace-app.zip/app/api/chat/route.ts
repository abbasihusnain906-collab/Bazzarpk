import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { generateText } from 'ai'
import { gateway } from 'ai/gateway'

export async function POST(request: Request) {
  try {
    const { message, history } = await request.json()

    // Fetch current listings from database
    const supabase = await createClient()
    const { data: listings } = await supabase
      .from('listings')
      .select('id, title, price, category, condition, city, description')
      .limit(50)

    const listingsContext = listings
      ? listings.map(l => 
          `- ${l.title}: Rs. ${l.price.toLocaleString()} in ${l.city} (${l.condition}, ${l.category})`
        ).join('\n')
      : 'No listings available'

    const systemPrompt = `You are a helpful assistant for BazaarPK, a Pakistani second-hand marketplace. 
You help users find listings, suggest items, and help sellers write listing descriptions.
Respond in English. Be friendly, helpful, and concise.

Current listings available:
${listingsContext}

When users ask about finding items:
- Suggest relevant listings from the database
- If no exact match, suggest similar items or categories
- Mention prices in PKR (Rs.)
- Suggest users browse specific categories if needed

When users ask for help writing listing descriptions:
- Help them write compelling, honest descriptions
- Include relevant details like condition, features, reason for selling
- Keep it concise but informative`

    const { text } = await generateText({
      model: gateway('google/gemini-2.0-flash-001'),
      system: systemPrompt,
      messages: [
        ...history.map((msg: { role: string; content: string }) => ({
          role: msg.role as 'user' | 'assistant',
          content: msg.content,
        })),
        { role: 'user' as const, content: message },
      ],
    })

    return NextResponse.json({ response: text })
  } catch (error) {
    console.error('Chat API error:', error)
    return NextResponse.json(
      { response: 'Sorry, I encountered an error. Please try again.' },
      { status: 500 }
    )
  }
}
