export const CATEGORIES = [
  { id: 'mobile', name: 'Mobile', icon: 'Smartphone' },
  { id: 'laptop', name: 'Laptop', icon: 'Laptop' },
  { id: 'furniture', name: 'Furniture', icon: 'Sofa' },
  { id: 'kapray', name: 'Kapray', icon: 'Shirt' },
  { id: 'electronics', name: 'Electronics', icon: 'Tv' },
  { id: 'books', name: 'Books', icon: 'BookOpen' },
  { id: 'cars', name: 'Cars', icon: 'Car' },
  { id: 'home-appliances', name: 'Home Appliances', icon: 'Refrigerator' },
] as const

export const CONDITIONS = [
  { id: 'brand-new', name: 'Brand New' },
  { id: 'good', name: 'Good' },
  { id: 'fair', name: 'Fair' },
  { id: 'needs-repair', name: 'Needs Repair' },
] as const

export const CITIES = [
  'Karachi',
  'Lahore',
  'Islamabad',
  'Rawalpindi',
  'Faisalabad',
  'Multan',
  'Peshawar',
] as const

export const SORT_OPTIONS = [
  { id: 'newest', name: 'Newest First' },
  { id: 'price-low', name: 'Price: Low to High' },
  { id: 'price-high', name: 'Price: High to Low' },
] as const

export type Category = (typeof CATEGORIES)[number]['id']
export type Condition = (typeof CONDITIONS)[number]['id']
export type City = (typeof CITIES)[number]
export type SortOption = (typeof SORT_OPTIONS)[number]['id']
