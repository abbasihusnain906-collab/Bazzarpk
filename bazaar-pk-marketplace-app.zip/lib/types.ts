export interface Listing {
  id: string
  user_id: string
  title: string
  price: number
  category: string
  condition: string
  city: string
  description: string | null
  whatsapp: string
  images: string[]
  created_at: string
  profiles?: {
    name: string | null
    avatar: string | null
  }
}

export interface Profile {
  id: string
  name: string | null
  email: string | null
  avatar: string | null
  phone: string | null
  city: string | null
  created_at: string
}

export interface Favorite {
  id: string
  user_id: string
  listing_id: string
  created_at: string
  listings?: Listing
}
