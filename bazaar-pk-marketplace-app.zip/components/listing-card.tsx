'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Heart, MapPin, MessageCircle } from 'lucide-react'
import { Listing } from '@/lib/types'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

interface ListingCardProps {
  listing: Listing
  isFavorite?: boolean
  showFavoriteButton?: boolean
  onFavoriteToggle?: () => void
}

export function ListingCard({ 
  listing, 
  isFavorite = false, 
  showFavoriteButton = true,
  onFavoriteToggle 
}: ListingCardProps) {
  const [favorite, setFavorite] = useState(isFavorite)
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-PK', {
      style: 'currency',
      currency: 'PKR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price).replace('PKR', 'Rs.')
  }

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'brand-new':
        return 'bg-green-500/20 text-green-400 border-green-500/30'
      case 'good':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30'
      case 'fair':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
      case 'needs-repair':
        return 'bg-red-500/20 text-red-400 border-red-500/30'
      default:
        return 'bg-muted text-muted-foreground'
    }
  }

  const formatCondition = (condition: string) => {
    return condition.split('-').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ')
  }

  const handleFavoriteClick = async (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/auth/login')
      return
    }

    setLoading(true)
    try {
      if (favorite) {
        await supabase
          .from('favorites')
          .delete()
          .eq('user_id', user.id)
          .eq('listing_id', listing.id)
      } else {
        await supabase
          .from('favorites')
          .insert({ user_id: user.id, listing_id: listing.id })
      }
      setFavorite(!favorite)
      onFavoriteToggle?.()
    } catch (error) {
      console.error('Error toggling favorite:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleWhatsAppClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    const message = encodeURIComponent(`Hi, I'm interested in your listing: ${listing.title} (${formatPrice(listing.price)})`)
    const phone = listing.whatsapp.replace(/[^0-9]/g, '')
    const formattedPhone = phone.startsWith('0') ? '92' + phone.slice(1) : phone
    window.open(`https://wa.me/${formattedPhone}?text=${message}`, '_blank')
  }

  const imageUrl = listing.images?.[0] || '/placeholder.svg'

  return (
    <Link href={`/listing/${listing.id}`}>
      <Card className="group overflow-hidden bg-card hover:bg-secondary/50 transition-all duration-200 border-border hover:border-primary/50">
        <div className="relative aspect-[4/3] overflow-hidden">
          <Image
            src={imageUrl}
            alt={listing.title}
            fill
            className="object-cover transition-transform duration-200 group-hover:scale-105"
          />
          {showFavoriteButton && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 h-8 w-8 bg-background/80 backdrop-blur-sm hover:bg-background"
              onClick={handleFavoriteClick}
              disabled={loading}
            >
              <Heart
                className={`h-4 w-4 ${favorite ? 'fill-primary text-primary' : 'text-foreground'}`}
              />
            </Button>
          )}
          <Badge className={`absolute bottom-2 left-2 ${getConditionColor(listing.condition)}`}>
            {formatCondition(listing.condition)}
          </Badge>
        </div>
        <CardContent className="p-4">
          <div className="space-y-2">
            <h3 className="font-semibold text-foreground line-clamp-1 group-hover:text-primary transition-colors">
              {listing.title}
            </h3>
            <p className="text-xl font-bold text-primary">
              {formatPrice(listing.price)}
            </p>
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                {listing.city}
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 gap-1 text-green-500 hover:text-green-400 hover:bg-green-500/10"
                onClick={handleWhatsAppClick}
              >
                <MessageCircle className="h-4 w-4" />
                WhatsApp
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
